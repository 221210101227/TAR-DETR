import warnings
import os
import pandas as pd
from ultralytics import RTDETR

warnings.filterwarnings('ignore')

if __name__ == '__main__':
    # 加载模型
    model = RTDETR(r'E:\shuoshi\to\RTDETR-20240926\RTDETR-main\runs\train\SCI\weights\best.pt')

    # 进行预测
    results = model.predict(source=r'E:\shuoshi\to\RTDETR-20240926\RTDETR-main\10张图',
                            conf=0.6,
                            project=R'E:\shuoshi\to\RTDETR-20240926\RTDETR-main\10张图',
                            name='exp',
                            save=True)

    # 创建保存先验框的文件夹
    save_dir = r'E:\shuoshi\to\RTDETR-20240926\RTDETR-main\10张图'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    # 遍历预测结果，保存每张图片的先验框数据
    for result in results:
        image_name = result.path.split(os.sep)[-1]  # 获取图片名
        boxes = result.boxes  # 获取先验框信息

        # 创建txt文件，保存先验框信息
        txt_path = os.path.join(save_dir, f"{os.path.splitext(image_name)[0]}_boxes.txt")
        with open(txt_path, 'w') as f:
            for box in boxes:
                # 获取框的位置和类别信息
                x1, y1, x2, y2 = box.xyxy[0]  # 左上角和右下角坐标
                confidence = box.conf[0]  # 置信度
                cls = box.cls[0]  # 类别

                # 写入txt文件
                f.write(
                    f"Class: {cls}, Confidence: {confidence:.2f}, BBox: ({x1:.2f}, {y1:.2f}), ({x2:.2f}, {y2:.2f})\n")

    print("先验框数据保存完毕。")